from django.db import models


# Create your models here.
class Heros(models.Model):
    name= models.CharField(max_length=50)
    breed=models.CharField(max_length=50)
    health=models.CharField(max_length=50)

def __str__(self):
     return self.name
class Hero(models.Model):
    names= models.CharField(max_length=50)
    breeds=models.CharField(max_length=50)
    healths=models.CharField(max_length=50)

def __str__(self):
     return self.names
